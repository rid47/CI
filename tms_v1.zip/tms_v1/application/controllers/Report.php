<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Report extends CI_Controller {


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Report
 *
 * @author Ridwan Mizan
 */

function __construct() {
        parent::__construct();
       
    }

public function avc()
	{
	       $this->load->view('common template/template');	
               $this->load->view('report/avcReport');
               $this->load->view('common template/footer');
                //$this->load->view('report/avcReport');
		
	}
public function dailypass()
	{
	      $this->load->view('common template/template');	
              $this->load->view('report/dailypassReport');
              $this->load->view('common template/footer');
		
	}
public function discrepancy()
	{
             $this->load->view('common template/template');		
             $this->load->view('report/discrepancyReport');
             $this->load->view('common template/footer');		
	}
public function exempt()
	{
    
                $this->load->view('common template/template');    
		$this->load->view('report/exemptReport');
                $this->load->view('common template/footer');
		
	}
public function efficiency()
	{
                $this->load->view('common template/template');    
		$this->load->view('report/efficiencyReport');
		$this->load->view('common template/footer');
	}
public function revenue()
	{
                
                $this->load->view('common template/template');    
       		$this->load->view('report/revenueReport');
		$this->load->view('common template/footer');
	}
public function shiftdetails()
	{
                $this->load->view('common template/template');
		$this->load->view('report/shiftdetailsReport');
		$this->load->view('common template/footer');
	}
public function trafficcount()
	{
                $this->load->view('common template/template');
		$this->load->view('report/trafficcountReport');
		$this->load->view('common template/footer');
	}
public function frequency()
	{
                $this->load->view('common template/template');
		$this->load->view('report/frequencyReport');
		$this->load->view('common template/footer');
        }
public function weigh()
	{
                $this->load->view('common template/template');
		$this->load->view('report/weighReport');
		$this->load->view('common template/footer');
	}    
public function weeklytraffic()
	{
                $this->load->view('common template/template');
		$this->load->view('report/weeklytrafficcensus');
		$this->load->view('common template/footer');
	}    
}

