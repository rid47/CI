<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Management extends CI_Controller {


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Report
 *
 * @author Ridwan Mizan
 */

function __construct() {
        parent::__construct();
       
    }

    public function shiftassign()
	{
                $this->load->view('common template/template');    
		$this->load->view('management/shiftassign');
		$this->load->view('common template/footer');
	}
    public function shiftConfiguration()
	{
	       $this->load->view('common template/template');	
               $this->load->view('management/shiftConfiguration');
               $this->load->view('common template/footer');
                
		
	}
public function plazaConfiguration()
	{
	      $this->load->view('common template/template');	
              $this->load->view('management/plazaConfiguration');
              $this->load->view('common template/footer');
		
	}
public function laneConfiguration()
	{
             $this->load->view('common template/template');		
             $this->load->view('management/laneConfiguration');
             $this->load->view('common template/footer');		
	}
public function vehicleClassManagement()
	{
    
                $this->load->view('common template/template');    
		$this->load->view('management/vehicleClassManagement');
                $this->load->view('common template/footer');
		
	}

public function classwisetarrif()
	{
                
                $this->load->view('common template/template');    
       		$this->load->view('management/classwisetarrif');
		$this->load->view('common template/footer');
	}
public function userCreation()
	{
                $this->load->view('common template/template');
		$this->load->view('management/userCreation');
		$this->load->view('common template/footer');
	}
public function userConfiguration()
	{
                $this->load->view('common template/template');
	        $this->load->view('management/userConfiguration');
		$this->load->view('common template/footer');
	}
}

