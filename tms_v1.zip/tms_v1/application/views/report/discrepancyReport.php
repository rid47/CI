<div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        Discrepancy Report
                        
                    </h1>
                    
                </section>
</div>