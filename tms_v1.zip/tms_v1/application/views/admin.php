<div class="content-wrapper">
                <!-- Content Header (Page header) -->
                
			
		<section class="content-header">
                    <h1>
                       Admin Panel
                        
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li class="active">Dashboard</li>
                    </ol>
                </section>

                      

        <!-- ./wrapper -->
<!-- Main Container starts -->
			
		
			<div class="main-container">

				<!-- Container fluid Starts -->
				<div class="container-fluid">
				
				

					<!-- Current Stats Start -->
			
					<div class="current-stats">
						<div class="row">
							<div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
								<div class="danger-bg center-align-text">
									<div class="spacer-xs">
										<small class="text-white">Class A</small>
										<h3 class="no-margin no-padding">19%</h3>
									</div>
								</div>
							</div>
							<div class="col-lg-2 col-md-4 col-sm-4 col-xs-6">
								<div class="success-bg center-align-text">
									<div class="spacer-xs">
										<small class="text-white">Class B</small>
										<h3 class="no-margin no-padding text-white">7%</h3>
									</div>
								</div>
							</div>
							<div class="col-lg-2 col-md-4 col-sm-4 col-xs-6">
								<div class="info-bg center-align-text">
									<div class="spacer-xs">
										<small class="text-white">Class C</small>
										<h3 class="no-margin no-padding">16%</h3>
									</div>
								</div>
							</div>
							<div class="col-lg-2 col-md-4 col-sm-4 col-xs-6">
								<div class="brown-bg center-align-text">
									<div class="spacer-xs">
										<small class="text-white">Class D</small>
										<h3 class="no-margin no-padding">5%</h3>
									</div>
								</div>
							</div>
							
							<div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
								<div class="linkedin-bg center-align-text">
									<div class="spacer-xs">
										<small class="text-white">Class E</small>
										<h3 class="no-margin no-padding">14%</h3>
									</div>
								</div>
							</div>
							</div>
							<div class="row">
							
							<div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
								<div class="danger-bg center-align-text">
									<div class="spacer-xs">
										<small class="text-white">Class F</small>
										<h3 class="no-margin no-padding">9%</h3>
									</div>
								</div>
							</div>
							<div class="col-lg-2 col-md-4 col-sm-4 col-xs-6">
								<div class="success-bg center-align-text">
									<div class="spacer-xs">
										<small class="text-white">Class G</small>
										<h3 class="no-margin no-padding text-white">7%</h3>
									</div>
								</div>
							</div>
							<div class="col-lg-2 col-md-4 col-sm-4 col-xs-6">
								<div class="info-bg center-align-text">
									<div class="spacer-xs">
										<small class="text-white">Class H</small>
										<h3 class="no-margin no-padding">23%</h3>
									</div>
								</div>
							</div>
							<div class="col-lg-2 col-md-4 col-sm-4 col-xs-6">
								<div class="brown-bg center-align-text">
									<div class="spacer-xs">
										<small class="text-white">Class I</small>
										<h3 class="no-margin no-padding">11%</h3>
									</div>
								</div>
							</div>
							<div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
								<div class="linkedin-bg center-align-text">
									<div class="spacer-xs">
										<small class="text-white">Class J</small>
										<h3 class="no-margin no-padding">1%</h3>
									</div>
								</div>
							</div>
							
						</div>
					</div>
                                </div>
                        </div>
					
					