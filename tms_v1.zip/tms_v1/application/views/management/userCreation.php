<div class="content-wrapper">
   
   <section class="content-header">
     <form class="form-horizontal" action="/action_page.php">
	  <div class="form-group" style="margin-left:55px">
		<label class="control-label col-sm-2" for="email">Name:</label>
		<div class="col-sm-7">
	
		  <input type="text" class="form-control" required id="text" placeholder="Enter Name">
		  </div>
	  </div>
	  
	  <div class="form-group" style="margin-left:55px">
		<label class="control-label col-sm-2" for="email">Employee Id:</label>
		<div class="col-sm-7">
	
		  <input type="text" class="form-control" required id="text" placeholder="Enter ID">
		  </div>
	  </div>
	  
	
	  <div class="form-group" style="margin-left:55px">
		<label class="control-label col-sm-2" for="pwd">User Role:</label>
			<div class="col-md-2 selectContainer">
				<select class="form-control" name="genre">
					<option value="comedy">Admin</option>
					<option value="action">Operator</option>
                                        <option value="super">Super Admin</option>
														
			    </select>
			</div>
	</div>
		
			  <div class="form-group" style="margin-left:55px">
		<label class="control-label col-sm-2" for="email">Email :</label>
		<div class="col-sm-7">
	
		  <input type="text" required class="form-control" id="text" placeholder="Enter Email">
		  </div>
	  </div>
	  
	  <div class="form-group" style="margin-left:55px">
		<label class="control-label col-sm-2" for="email">Password :</label>
		<div class="col-sm-7">
	
		  <input required type="password" class="form-control" id="password" placeholder="Enter Password">
		  </div>
	  </div>
	  	  <div class="form-group" style="margin-left:55px">
			<label class="control-label col-sm-2" for="email">Retype Password:</label>
			<div class="col-sm-7">
		
			  <input type="password" required class="form-control" id="password" placeholder="Enter Retype Password">
			</div>
		</div>
		<div class="col-sm-8">
		
		</div>
		<div class="btn-group">
				  <input type="submit" class="btn btn-primary" value="Save"></input>
	  </div>
	  
	  
</form> 
</section>
</div>