<div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        Vehicle Class Management
                        
                    </h1>
                    
                </section>
</div>