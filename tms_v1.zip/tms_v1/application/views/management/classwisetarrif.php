<div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        Class Wise Tarrif Management
                        
                    </h1>
                    
                </section>
</div>