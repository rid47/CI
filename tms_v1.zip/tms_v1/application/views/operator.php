<div class="main-container">

				<!-- Container fluid Starts -->
				<div class="container-fluid">

					<!-- Current Stats Start -->
					<div class="current-stats">
						<div class="row">
							<div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
								<div class="danger-bg center-align-text">
									<div class="spacer-xs">
										<small class="text-white">Class A</small>
										<h3 class="no-margin no-padding">19%</h3>
									</div>
								</div>
							</div>
							<div class="col-lg-2 col-md-4 col-sm-4 col-xs-6">
								<div class="success-bg center-align-text">
									<div class="spacer-xs">
										<small class="text-white">Class B</small>
										<h3 class="no-margin no-padding text-white">7%</h3>
									</div>
								</div>
							</div>
							<div class="col-lg-2 col-md-4 col-sm-4 col-xs-6">
								<div class="info-bg center-align-text">
									<div class="spacer-xs">
										<small class="text-white">Class C</small>
										<h3 class="no-margin no-padding">16%</h3>
									</div>
								</div>
							</div>
							<div class="col-lg-2 col-md-4 col-sm-4 col-xs-6">
								<div class="brown-bg center-align-text">
									<div class="spacer-xs">
										<small class="text-white">Class D</small>
										<h3 class="no-margin no-padding">5%</h3>
									</div>
								</div>
							</div>
							
							<div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
								<div class="linkedin-bg center-align-text">
									<div class="spacer-xs">
										<small class="text-white">Class E</small>
										<h3 class="no-margin no-padding">14%</h3>
									</div>
								</div>
							</div>
							</div>
							<div class="row">
							
							<div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
								<div class="danger-bg center-align-text">
									<div class="spacer-xs">
										<small class="text-white">Class F</small>
										<h3 class="no-margin no-padding">9%</h3>
									</div>
								</div>
							</div>
							<div class="col-lg-2 col-md-4 col-sm-4 col-xs-6">
								<div class="success-bg center-align-text">
									<div class="spacer-xs">
										<small class="text-white">Class G</small>
										<h3 class="no-margin no-padding text-white">7%</h3>
									</div>
								</div>
							</div>
							<div class="col-lg-2 col-md-4 col-sm-4 col-xs-6">
								<div class="info-bg center-align-text">
									<div class="spacer-xs">
										<small class="text-white">Class H</small>
										<h3 class="no-margin no-padding">23%</h3>
									</div>
								</div>
							</div>
							<div class="col-lg-2 col-md-4 col-sm-4 col-xs-6">
								<div class="brown-bg center-align-text">
									<div class="spacer-xs">
										<small class="text-white">Class I</small>
										<h3 class="no-margin no-padding">11%</h3>
									</div>
								</div>
							</div>
							<div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
								<div class="linkedin-bg center-align-text">
									<div class="spacer-xs">
										<small class="text-white">Class J</small>
										<h3 class="no-margin no-padding">1%</h3>
									</div>
								</div>
							</div>
							
						</div>
					</div>
					<!-- Current Stats End -->
<!-- Row Starts -->
						<div class="row">
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
								<div class="blog">
									<div class="blog-header">
										<h5 class="blog-title">Picture</h5>
									</div>
									<div class="blog-body">
										
										
										
									</div>
								</div>
							</div>
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
								<div class="blog">
									<div class="blog-header">
										<h5 class="blog-title">In Processe</h5>
									</div>
									<div class="blog-body">
										<form id="movieForm" method="post">
											<div class="form-group">
												<div class="row">
													<div class="col-md-8">
														<label class="control-label">Licence No</label>
														<input type="text" class="form-control" name="title" />
													</div>
													<div class="col-md-4 selectContainer">
														<label class="control-label">Class</label>
														<select id="SelectClass" class="form-control" name="genre">
															<option value="A">A</option>
															<option value="B">B</option>
															<option value="C">C</option>
															<option value="D">D</option>
															<option value="E">E</option>
															<option value="F">F</option>
															<option value="G">G</option>
															<option value="H">H</option>
															<option value="I">I</option>
															<option value="J">J</option>
														</select>
													</div>
												</div>
											</div>	
											<div class="form-group">
												<div class="row">
												<div id="demo" style="display:none">		
													 <div class="col-md-12">
														<label class="control-label">Weight</label>
														<input type="text" class="form-control" name="title" />
														
													</div>
												 </div>
												</div>
											</div>
											<div class="form-group">
												<div class="row">
													<div class="col-md-6">
														<label class="control-label">Time</label>
														<input type="text" class="form-control" name="director" />
													</div>
													<div class="col-md-6">
														<label class="control-label">Date</label>
														<input type="text" class="form-control" name="writer" />
													</div>
													
												</div>
											</div>
											<div class="form-group">
												<div class="row">
													<div class="col-md-4">
														<label class="control-label">Bill</label>
														<input type="text" class="form-control" name="website" />
													</div>
													<div class="col-md-4">
														<label class="control-label">Amount Paid</label>
														<input type="text" class="form-control" name="trailer" />
													</div>
													
													<div class="col-md-4">
														<label class="control-label">Change</label>
														<input type="text" class="form-control" name="website" />
													</div>
													
												</div>
											</div>
											
												<div class="col-md-6">
														
													</div>
													<div class="col-md-4">
														
													</div>
											<div class="col-md-1">
													<button type="submit" class="btn btn-default">Print</button>
											</div>
										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
			</div>


<script>
			$(document).ready(function(){
			  $('#SelectClass').on('change', function() {
				  var data = $("#SelectClass").val()
				  if(data== 'D' || data== 'E'){
					  $("#demo").show() 
				  }
				 
			  else
			  {
				  $("#demo").hide() 
			  }
			  
			})
				  
			
			});
		</script>